$(function(){
	$('[href=#]').click(function(){
		$('body').hide();
	});
});